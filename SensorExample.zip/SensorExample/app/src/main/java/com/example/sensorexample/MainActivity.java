package com.example.sensorexample;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.lang.reflect.Type;

public class MainActivity extends AppCompatActivity implements SensorEventListener, View.OnClickListener {

    private EditText editTextX,editTextY,editTextZ;
    private Button button;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    float acclX =0, acclY=0,acclZ=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextX = findViewById(R.id.editTextX);
        editTextY = findViewById(R.id.editTextY);
        editTextZ = findViewById(R.id.editTextZ);
        button = findViewById(R.id.button);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        button.setOnClickListener(this);



//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//               switch (v.getId()){
//                   case R.id.button:
//                      // sensorManager.registerListener(accelerometer,SensorManager.SENSOR_DELAY_FASTEST)
//                       sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_FASTEST);
//                       editTextX.setText("12");
//                       break;
//               }
//            }
//        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
                   case R.id.button:
                      // sensorManager.registerListener(accelerometer,SensorManager.SENSOR_DELAY_FASTEST)
                       sensorManager.registerListener(MainActivity.this,accelerometer,0);
//                       editTextX.setText(new Float(acclX).toString());
//                       editTextY.setText(new Float(acclY).toString());
//                       editTextZ.setText(new Float(acclZ).toString());
                       break;
               }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            acclX = event.values[0];
            acclY = event.values[1];
            acclZ = event.values[2];

            editTextX.setText(new Float(acclX).toString());
            editTextY.setText(new Float(acclY).toString());
            editTextZ.setText(new Float(acclZ).toString());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}